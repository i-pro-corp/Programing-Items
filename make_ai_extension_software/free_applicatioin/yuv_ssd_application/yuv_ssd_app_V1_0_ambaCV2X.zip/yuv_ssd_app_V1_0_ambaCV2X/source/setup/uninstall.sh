echo 'Uninstaller start'

# アプリアンインストール時に必要な処理を記述する(空でもよい)

echo 'Uninstaller done'

exit 0
