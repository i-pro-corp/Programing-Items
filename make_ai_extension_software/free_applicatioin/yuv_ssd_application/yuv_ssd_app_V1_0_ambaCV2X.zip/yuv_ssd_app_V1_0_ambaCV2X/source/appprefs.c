/**
 * @addtogroup  Adam Sample Application
 * @{
 * @file        appprefs.c
 * @brief       Adam YUV SSD Sample Application (SKELETON Model)
 *
 * @author      R.Hamabe
 *
 * @par Copyright
 * Copyright (C) 2019 Panasonic i-PRO Sensing Solutions Co., Ltd. All rights reserved.
 * Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 */

/** Header files for Debug Log */
#define ADAM_APP_DEBUG_ENABLE 1
#include "AdamDebug.h"
#include "AdamAssert.h"

#include "appprefs.h"

static int s_frameRate;
static unsigned int s_resolution;

static struct {
	int m_width;
	int m_height;
} s_resolutions[] = {
	{1280,  720}, /** HD */
	{1920, 1080}, /** FHD */
};

E_ADAM_ERR appprefs_init(void)
{
	/** Lock to access from WebAPI (for exclusion). */
	ADAM_AppPref_Lock();

	/** Get Resolution */
	ADAM_AppPref_GetEnumeration("Resolution", &s_resolution);

	/** Get Frame rate */
	int64_t frameRate;
	ADAM_AppPref_GetInteger("FrameRate", &frameRate);
	s_frameRate = (int)frameRate;

	/** Unlock to access from WebAPI. */
	ADAM_AppPref_Unlock();

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "Resolution=%d, Framerate=%d\n", s_resolution, s_frameRate);
	return ADAM_ERR_OK;
}


void appprefs_get_YcVideoProperty(ST_ADAM_DEV_YCVIDEO_PROPERTY* pProperty)
{
	/** set resolution  */
	int width = appprefs_get_resolution_width();
	int height = appprefs_get_resolution_height();
	pProperty->m_resolution = ADAM_SET_RESOLUTION(width, height);

	/** set frame rate */
	pProperty->m_frameRate = ADAM_SET_FRAME_RATE(s_frameRate, 1);

	return;
}


int appprefs_get_framerate(void)
{
	return s_frameRate;
}


int appprefs_get_resolution_width(void)
{
	return s_resolutions[s_resolution].m_width;
}


int appprefs_get_resolution_height(void)
{
	return s_resolutions[s_resolution].m_height;
}

/*! @} */
