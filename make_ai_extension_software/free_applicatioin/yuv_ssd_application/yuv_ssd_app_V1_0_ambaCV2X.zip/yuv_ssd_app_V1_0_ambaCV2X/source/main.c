/**
 * @addtogroup  Adam Sample Application
 * @{
 * @file        main.c
 * @brief       Adam YUV SSD Sample Application (SKELETON Model)
 *
 * @author      FSI
 *
 * @par Copyright
 * Copyright (C) 2019 Panasonic i-PRO Sensing Solutions Co., Ltd. All rights reserved.
 * Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 *
 *
 * @note
 *   === How to use this application ===
 *     1. Start Adam and sdkCAM by executing startAdam.sh with -s option.
 *     2. Install this application using Adam Operation UI.
 *     3. Start this application using Adam Operation UI on web browser.
 *     4. Input the following URL on web browser.
 *          http://@IP_ADDRESS@/cgi-bin/adam.cgi?methodName=sendDataToAdamApplication&installId=@INSTALL_ID@&s_appDataType=0&s_appData=
 *           @IP_ADDRESS@ : IP address of device which is executed this application.
 *           @INSTALL_ID@ : Install Id of this application.
 *     5. If sucess, displayed a SSD result on web browser.
 */



/** Header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "pthread.h"

/** Header file for AdamApp Header */
#include "AdamApi.h"  

/** Header files for Debug Log */
#define ADAM_APP_DEBUG_ENABLE 1
#include "AdamDebug.h"
#include "AdamAssert.h"

/** Header file for AppPrefs */
#include "appprefs.h"


/**
 *   Input detected image resolution
 *   入力される検知時の画像解像度
*/
#define INDET_WIDTH		1024
#define INDET_HEIGHT		1024

/**
 *   Image resolution before resizing
 *   リサイズ前画像解像度
*/
static unsigned int in_height;
static unsigned int in_width;

/**
 *   Image resolution after resizing
 *   リサイズ後画像解像度
*/
#define OUTSIZE_HEIGHT		300
#define OUTSIZE_WIDTH		300

#define DEPTH_YCRESIZE		1.5
#define DEPTH_RGBRESIZE		3

#define NETNAME							"mobilenetv1_ssd_cavalry.bin"
#define PRIORBOXFILE					"mobilenet_priorbox_fp32.bin"
#define LAYERNAMEIN						"data"
#define LAYERNAMEOUT_MBOX_LOC			"mbox_loc"
#define LAYERNAMEOUT_MBOX_CONF_FLATTEN	"mbox_conf_flatten"

/** SSD property */
#define PROPERTY_NUMCLASSES				21
#define PROPERTY_MBOXLOCSIZE			7668
#define PROPERTY_IMGWIDTH				OUTSIZE_WIDTH
#define PROPERTY_IMGHEIGHT				OUTSIZE_HEIGHT
#define PROPERTY_BACKGROUND_LABEL_ID	0
#define PROPERTY_CONFTHRESHOLD			0.4
#define PROPERTY_KEEP_TOP_K				50
#define PROPERTY_NUMSTHRESHOLD			0.45
#define PROPERTY_NUMS_TOP_K				100
#define PROPERTY_PRIORBOXFILE			PRIORBOXFILE

/** SSD property (Only for Tensorflow SSD) */
#define X_SCALE							0.0
#define Y_SCALE							0.0
#define WIDTH_SCALE						0.0
#define HEIGHT_SCALE					0.0

/** label-objectname matrix*/
const char * objectname[] = { 
	 "background"
	,"aeroplane"
	,"bicycle"
	,"bird"
	,"boat"
	,"bottle"
	,"bus"
	,"car"
	,"cat"
	,"chair"
	,"cow"
	,"diningtable"
	,"dog"
	,"horse"
	,"motorbike"
	,"person"
	,"pottedplant"
	,"sheep"
	,"sofa"
	,"train"
	,"tvmonitor"
};

/** Static variables */
static T_ADAM_EVENTLOOP_ID   s_systemEventloopId = ADAM_INVALID_EVENTLOOP_ID; /* System Eventloop */
static T_ADAM_DEV_RAWVIDEO_ID s_ycvideoDevId = ADAM_INVALID_DEV_ID;

static unsigned int s_count = 0;
static ST_ADAM_SSD_RESULT Result;

static T_ADAM_NET_ID netid = -1;
static T_ADAM_SSD_ID ssdid = -1;

static ST_ADAM_BLOB ycInBlob;
static ST_ADAM_BLOB ycOutBlob;
static ST_ADAM_BLOB netInBlob;
static ST_ADAM_BLOB netOutBlobMboxLoc;
static ST_ADAM_BLOB netOutBlobMboxConfFlatten;

/** Data to send to HTML by web socket */
#define SEND_LIST_MAX	50
#define LABEL_NAME_MAX	30
static char result_label_list[SEND_LIST_MAX][LABEL_NAME_MAX];

/** Function declarations */
extern int main( int argc, char* argv[] );
static E_ADAM_ERR create_DevYcVideo();
static void	stop_handler( E_ADAM_STOP_FACTOR factor );
static void	server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData );
static void	ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg );
static int	runnet(void);
static int	runssd(void);
void response_by_html( T_ADAM_REQUEST_ID requestId );

extern int main3(int argc, const char **argv);
extern void sendResult(ST_ADAM_SSD_RESULT_ELEMENT* list, unsigned int num, char * send_label_list, unsigned int send_width, unsigned int send_height);
/*******************************************************************************/
/**
 * @brief thread for connection
 *        ADAMとの通信用スレッド
 * @param p   [in] void*   some arguments
 */
void *func_thread(void *p){
	main3(0, NULL);
}

/**
 *   @brief main function
 *
 *   @param argc   [in] int   Count of arguments
 *   @param argv[] [in] char* Arguments
 *
 *   @return int 0      Normal response
 *   @return int <0     Abnormal response
 */
int main( int argc, char* argv[] )
{
	E_ADAM_ERR			err;			/** ADAM error code */
	int				ret = 0;		/** Return value of this function */
	ST_ADAM_SYSTEM_HANDLERS		handlers;		/** Handlers required by ADAM system */
	E_ADAM_START_FACTOR		startFactor;		/** Start factor (In this Adam version, not defined) */
	ST_ADAM_SSD_PROPERTY 		property;
	pthread_t			pthread;		/** Thread for web-socket */

	/**
	 *  Start to use ADAM library
	 *  ADAMライブラリの使用開始
	 *   Create the system event loop and set systemEventloopId
	 *   同時にイベントループも生成され、systemEventloopIdが返される
	 *   Arg 1 is the coding model about this application
	 *   第一引数ではアプリのコーディングモデルを指定する。
	 *   - ADAM_APP_TYPE_SKELETON   : Create only the main thread and use worker threads
	 *                                メインスレッドとWorkerスレッドのみで全ての処理を行うモデル。
	 *   - ADAM_APP_TYPE_FREE_STYLE : User can freely make threads for this application
	 *                                自由にスレッドを起こして処理を行うモデル。
	 *    This sample program is using the model of SKELETON.
	 *    （このアプリはSKELETONモデルとして動作します）
	 */
	handlers.m_stopHandler                 = stop_handler;
	handlers.m_serverRequestReceiveHandler = server_request_receive_handler;
	handlers.m_notifyAppPrefUpdateHandler  = 0;
	err = ADAM_Open( ADAM_APP_TYPE_SKELETON, &handlers, &s_systemEventloopId, &startFactor );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Open: ERROR=%d\n", err);
		ret = -1;
		goto errend;
	}

	pthread_create(&pthread, NULL, &func_thread, NULL);	//To use connection from HTM in ADAM

	/**
	 *    設定値情報初期化 (設定値情報から必要な値を取得)
	 *    Initialize the AppPrefs. (Get the needed parameter from AppPrefs.)
	 */
	appprefs_init();

	/**
	 *   Neural Networkの定義ファイルオープン
	 */
	err = ADAM_AI_OpenNet(NETNAME, &netid);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_OpenNet err! err:%d\n",err);
		ret = -2;
		goto adam_close;
	}

    /**
     *   Initialize object detection using SSD model
     *   SSDによる物体検出処理の初期化
     */
	memset(&property, 0x00, sizeof(ST_ADAM_SSD_PROPERTY));
    property.m_num_classes = PROPERTY_NUMCLASSES;
    property.m_mbox_loc_size = PROPERTY_MBOXLOCSIZE;
    property.img_width = PROPERTY_IMGWIDTH;
    property.img_height = PROPERTY_IMGHEIGHT;
    property.m_background_label_id = PROPERTY_BACKGROUND_LABEL_ID;
    property.m_conf_threshold = PROPERTY_CONFTHRESHOLD;
    property.m_keep_top_k = PROPERTY_KEEP_TOP_K;
    property.m_nms_threshold = PROPERTY_NUMSTHRESHOLD;
    property.m_nms_top_k = PROPERTY_NUMS_TOP_K;
	property.m_priorbox_filename = PROPERTY_PRIORBOXFILE;
	property.m_x_scale = X_SCALE;
	property.m_y_scale = Y_SCALE;
	property.m_width_scale = WIDTH_SCALE;
	property.m_height_scale = HEIGHT_SCALE;
	err = ADAM_AI_InitSSD(&property, &ssdid);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_InitSSD err! err:%d\n",err);
		ret = -3;
		goto net_close;
	}

	in_height = appprefs_get_resolution_height();
	in_width = appprefs_get_resolution_width();

    /**
     *   Create Blob data area before resizing
     *   リサイズ前Blobデータ領域を作成
     */
	err = ADAM_CV_CreateBlob(ADAM_YC_CHANNELS, in_height, in_width, 1, &ycInBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_CreateBlob err! err:%d\n",err);
		ret = -4;
		goto ssd_close;
	}

    /**
     *   Create Blob data area after resizing
     *   リサイズ後Blobデータ領域を作成
     */
	err = ADAM_CV_CreateBlob(ADAM_YC_CHANNELS, OUTSIZE_HEIGHT, OUTSIZE_WIDTH, 1, &ycOutBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_CreateBlob err! err:%d\n",err);
		ret = -5;
		goto yc_in_blob_close;
	}

    /**
     *   Get input blob data area of neural network
     *   Neural Networkの入力Blobデータ領域取得
     */
	err = ADAM_AI_BlobByName(netid, LAYERNAMEIN, &netInBlob);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_BlobByName(data) err! err:%d\n",err);
		ret = -6;
		goto yc_out_blob_close;
	}

    /**
     *   Get output blob data area of neural network(mbox_loc)
     *   Neural Networkの出力Blobデータ領域取得(mbox_conf_flatten)
     */
	err = ADAM_AI_BlobByName(netid, LAYERNAMEOUT_MBOX_LOC, &netOutBlobMboxLoc);
	if ( ADAM_ERR_OK != err ) {
        ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_BlobByName(mbox_loc) err! err:%d\n",err);
		ret = -7;
		goto yc_out_blob_close;
	}

    /**
     *   Get output blob data area of neural network(mbox_conf_flatten)
     *   Neural Networkの出力Blobデータ領域取得(mbox_conf_flatten)
     */
	err = ADAM_AI_BlobByName(netid, LAYERNAMEOUT_MBOX_CONF_FLATTEN, &netOutBlobMboxConfFlatten);
	if ( ADAM_ERR_OK != err ) {
        ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_BlobByName(mbox_conf_flatten) err! err:%d\n",err);
		ret = -8;
		goto yc_out_blob_close;
	}

	/**
	 *   YcVideo取得用資源の生成とイベントループへの登録
	 *   Generates a YcVideo resource and registers it in System Eventloop
	 */
	err = create_DevYcVideo( s_systemEventloopId );
	if( ADAM_ERR_OK != err ){
		ret = -9;
		goto yc_out_blob_close;
	}

	/**
	 *  Start main event loop
	 *  イベントループの開始
	 *   This function is loops infinitely until ADAM_Eventloop_Exit() is called.
	 *   ADAM_Eventloop_Exit()が呼ばれるまで、この関数から抜けてこず
	 *   Call the registered event handlers when events occur.
	 *   各種イベント発生毎に、登録したイベントハンドラが呼ばれる。
	 */
	err = ADAM_Eventloop_Dispatch( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Dispatch: ERROR=%d\n", err);
		ret = -10;
	}

	/**
	 *  Call stop_handler() when the event loop receives the stop application event
	 *  システム(コア)から終了通知を受けると、stop_handlerが呼ばれる。
	 *
	 *  stop_handler() calls ADAM_Eventloop_Exit(), so ADAM_Eventloop_Dispatch()
	 *  will quit the loop and return to this main() function.
	 *  stop_handlerの実装でADAM_Eventloop_Exit()を呼び出しているので、
	 *  ADAM_Eventloop_Dispatch()から抜けて、このmain()関数に処理が戻る。
	 */

yc_out_blob_close:
    /**
     *   Delete the output Blob data area
     *   出力Blobデータ領域を削除
     */
	err = ADAM_CV_DeleteBlob(&ycOutBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_DeleteBlob err!\n");
	}
yc_in_blob_close:
    /**
     *   Delete input Blob data area
     *   入力Blobデータ領域を削除
     */
	err = ADAM_CV_DeleteBlob(&ycInBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_DeleteBlob err!\n");
	}
ssd_close:
    /**
     *   Release initialized resource
     *   SSD解放   
     */
	err = ADAM_AI_DeInitSSD(ssdid);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_DeInitSSD err!\n");
		ret = -11;
	}
net_close:
    /**
     *   Close neural network
     *   Neural Networkクローズ
     */
	err = ADAM_AI_CloseNet(netid);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_CloseNet err!\n");
		ret = -12;
	}
adam_close:
    /**
     *   Close ADAM library
     *   ADAMライブラリの使用終了
     */
	err = ADAM_Close();
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Close: ERROR=%d\n", err);
		ret = -13;
	}
errend:
	return ret;
}

/**
 *   @brief YcVideo取得用資源の生成とイベントループへの登録
 *          Generates a YcVideo resource and registers it in Eventloop
 *
 *   @param eventloopId   [in] int   Eventloop Id
 *
 *   @return ADAM_ERR_OK         Normal response
 *   @return except ADAM_ERR_OK  Abnormal response
 */
E_ADAM_ERR create_DevYcVideo( T_ADAM_EVENTLOOP_ID eventloopId )
{
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "create_DevYcVideo start\n");

	ST_ADAM_DEV_YCVIDEO_PROPERTY property;
	appprefs_get_YcVideoProperty(&property);

	/** Generate a Yc video Resource. */
	E_ADAM_ERR err = ADAM_DevYcVideo_Create( &property, ycvideo_handler, (void*)(1001), &s_ycvideoDevId );
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "create_DevYcVideo(1)\n");

	if ( ADAM_ERR_OK != err ){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_DevYcVideo_Create: ERROR=%d\n", err);
		return err;
	}

	/** Regeister a Yc video resource in Eventloop. */
	err = ADAM_Eventloop_Add( eventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Add: ERROR=%d\n", err);
		return err;
	}

	return ADAM_ERR_OK;
}


/**
 *  @brief Handler for the application STOP request from adamCore process
 *         終了イベントハンドラ
 *  @param factor   [in] E_ADAM_STOP_FACTOR   Stop factor
 */
void stop_handler( E_ADAM_STOP_FACTOR factor )
{
	/**
	 *   Remove the Yc video resource from System Eventloop.
	 *   (In this removal, the Yc video resource is destroyed.)
	 *   システムイベントループから、YcVideo取得用資源を削除
	 *    (この削除により、YcVideo取得用資源も破棄されます)
	 */
	E_ADAM_ERR err = ADAM_Eventloop_Remove( s_systemEventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Remove: ERROR=%d\n", err);
	}

	/**
	 *   Request the main eventloop to stop
	 *   main()側のイベントループの終了を指示
	 */
	err = ADAM_Eventloop_Exit( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Exit: ERROR=%d\n", err);
	}
}


/**
 * @brief Handler for the sending application data request from the host ( via adamCore )
 *        アプリデータ受信ハンドラ
 *
 * @param requestId [in] T_ADAM_REQUEST_ID   Request ID
 * @param pData     [in] ST_ADAM_NET_DATA    Received Data
 */
void server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData )
{
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "requestId=%x start\n", (int)requestId);
	response_by_html(requestId);
	return;
}

/**
 *   @brief Handler to notify to receive Yc Video data
 *          Yc画像受信イベントハンドラの記述
 *
 *   @param devId [in] T_ADAM_DEV_YCVIDEO_ID     YCVIDEO device ID
 *   @param pData [in] ST_ADAM_DEV_YCVIDEO_DATA* YCVIDEO data
 */

void ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg )
{
	int ret;
	E_ADAM_ERR err;

	ADAM_ASSERT( s_ycvideoDevId == devId );

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "ycvideo_handler start\n");

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "%05d: ycvideo devid = %ld, ycvideo data size = %d\n",
                     ++s_count, (long)devId, pData->m_size);

    /**
     *   Set data to Blob before resizing
     *   リサイズ前Blobへデータを設定
     */
	err = ADAM_CV_SetCpuData(&ycInBlob, pData->m_pData);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_SetCpuData err! err:%d\n",err);
		return;
	}

	ST_ADAM_AREA_INFO resizeIn;
	memset(&resizeIn, 0x00, sizeof(ST_ADAM_AREA_INFO));
	memcpy(&resizeIn.m_blob, &ycInBlob, sizeof(ST_ADAM_BLOB));

    /**
     *   Resize YC image
     *   YC画像リサイズ
     */
	err = ADAM_CV_YcResize(&resizeIn, &ycOutBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_YcResize err! err:%d\n",err);
		return;
	}

	ST_ADAM_AREA_INFO ycInfo;
	memset(&ycInfo, 0x00, sizeof(ST_ADAM_AREA_INFO));
	memcpy(&ycInfo.m_blob, &ycOutBlob, sizeof(ST_ADAM_BLOB)); 

    /**
     *   Convert YC image to RGB image
     *   YC画像をBGR画像に変換
     */
	err = ADAM_CV_Yc2Rgb(&ycInfo, &netInBlob, ADAM_COLOR_ORDER_BGR);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_Yc2Rgb err! err:%d\n",err);
		return;
	}

    /**
     *   Run inference of neural network
     *   Networkの推論実行
     */
	ret = runnet();
	if(ret != 0){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "runnet err! ret:%d\n",ret);
		return;
	}

    /**
     *   Execute object detection
     *   物体検知
     */
	ret = runssd();
	if(ret != 0){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "runssd err! ret:%d\n",ret);
		return;
	}


    /**
     *   Send result data
     *   結果送信
     */
	sendResult(Result.m_element, Result.m_detnum, result_label_list, in_width, in_height);

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "ycvideo_handler end\n");
}

/**
 * @brief Send the response data whose format is HTML
 *        HTML形式のレスポンスを返す
 * @param requestId [in] T_ADAM_REQUEST_ID   Request ID
 */
void response_by_html(T_ADAM_REQUEST_ID requestId)
{
	// Data for sending set by ADAM_ServerResponse_Send()
	// ADAM_ServerResponse_Sendに設定するデータ
	ST_ADAM_NET_DATA	resData;
	char*			htmlData = (char*)malloc(4096);		// HTML body data to send
	int			bodySize = 0;				// HTML body data size
	char*			outputData = (char*)malloc(4096);	// Response data(HTTP header + body)
	int			size = 0;				// Response data size
	E_ADAM_ERR		ret;

	const char *appPath = ADAM_GetAppDataDirPath();
	char fname[512];
	snprintf(fname, sizeof(fname), "%s/sample.htm", appPath);
	FILE *fp = fopen(fname, "r");
	if(fp){
		char buf[512];
		while(fgets(buf, 512, fp)){
			bodySize += sprintf(htmlData + bodySize, "%s\n", buf);
		}
		fclose(fp);
	}

	// Make sample HTML header (to calculate body size, this data is made after making HTML body)
	// サンプルのHTMLヘッダを生成(length計算のためにHTMLより後に生成が必要)
	size += sprintf(outputData + size, "HTTP/1.1 200 OK\n");
	size += sprintf(outputData + size, "Content-Type: text/html\n");
	size += sprintf(outputData + size, "Content-Length: %d\n", bodySize + 1);
	size += sprintf(outputData + size, "\n");

	// Add body behind the header
	// ヘッダの後ろにボディを連結
	memcpy(outputData + size, htmlData, bodySize);
	size += bodySize;

	resData.m_type  = 0;				// Ignore m_type when HTML mode
	resData.m_pData = outputData;			// Set the pointer of response data
	resData.m_size  = size;				// Response data size

	// Send response by ADAM_USER_DEFINED_FORMAT
	// ADAM_USER_DEFINED_FORMATとしてレスポンスを返す
	ret = ADAM_ServerResponse_Send(requestId, ADAM_USER_DEFINED_FORMAT, &resData);
	if(ADAM_ERR_OK != ret){
		// error handling
	}

	free(outputData);
	free(htmlData);
}

/**
 *  @brief Run inference of neural network
 *         Networkの推論実行
 */
int runnet(void)
{
	E_ADAM_ERR err;

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runnet start\n");
    
	/**
	 *   Run inference of neural network
	 *   Networkの推論実行
	 */
	err = ADAM_AI_RunNet(netid);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_RunNet err! err:%d\n",err);
		return -1;
	}

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runnet end\n");
	return 0;
}

/**
 *  @brief Execute object detection
 *         物体検知
 */
int runssd(void)
{
	E_ADAM_ERR err;

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runssd start\n");

	memset(&Result, 0x00, sizeof(ST_ADAM_SSD_RESULT));

	//Initialize label data
	for(int i = 0; i < SEND_LIST_MAX; i++){
		memset(result_label_list[i], '\0', LABEL_NAME_MAX);
	}

	/**
	 *   Execute object detection
	 *   物体検知処理
	 */
	err = ADAM_AI_RunSSD(ssdid, &netOutBlobMboxLoc, &netOutBlobMboxConfFlatten, &Result);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_RunSSD err! err:%d\n",err);
		return -1;
	}

	// Adjust each paramter and set label-name
	for(int i = 0; i < Result.m_detnum; i++){
		Result.m_element[i].m_box.m_posX = Result.m_element[i].m_box.m_posX * in_width / INDET_WIDTH;
		Result.m_element[i].m_box.m_posY = Result.m_element[i].m_box.m_posY * in_height / INDET_HEIGHT;
		Result.m_element[i].m_box.m_width = Result.m_element[i].m_box.m_width * in_width / INDET_WIDTH;
		Result.m_element[i].m_box.m_height = Result.m_element[i].m_box.m_height * in_height / INDET_HEIGHT;
		sprintf(result_label_list[i], "%s", objectname[Result.m_element[i].m_label]);
	}

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runssd end\n");
	return 0;
}
/*! @} */
