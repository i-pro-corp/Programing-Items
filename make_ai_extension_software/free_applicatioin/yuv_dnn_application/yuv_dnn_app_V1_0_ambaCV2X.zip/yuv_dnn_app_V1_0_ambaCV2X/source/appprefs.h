/**
 * @addtogroup  Adam Sample Application
 * @{
 * @file        appprefs.h
 * @brief       Adam YUV DNN Sample Application (SKELETON Model)
 *
 * @author      R.Hamabe
 *
 * @par Copyright
 * Copyright (C) 2019 Panasonic i-PRO Sensing Solutions Co., Ltd. All rights reserved.
 * Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 */

#if !defined(_APPPREFS_H_)
#define _APPPREFS_H_

#if defined(__cplusplus)
extern "C"{
#endif /* __cplusplus */

#include "AdamApi.h"

extern E_ADAM_ERR appprefs_init(void);
extern void appprefs_get_YcVideoProperty(ST_ADAM_DEV_YCVIDEO_PROPERTY* pProperty);
extern int appprefs_get_framerate(void);
extern int appprefs_get_resolution_width(void);
extern int appprefs_get_resolution_height(void);
	
#if defined(__cplusplus)
}
#endif /* __cplusplus */


/*! @} */
#endif /* _APPPREFS_*/