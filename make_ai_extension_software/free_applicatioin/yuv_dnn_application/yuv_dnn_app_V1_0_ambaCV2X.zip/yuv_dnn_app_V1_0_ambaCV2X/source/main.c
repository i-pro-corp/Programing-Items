/**
 * @addtogroup  Adam Sample Application
 * @{
 * @file        main.c
 * @brief       Adam YUV DNN Sample Application
 *
 * @author      R.Hamabe
 *
 * @par Copyright
 * Copyright (C) 2019 Panasonic i-PRO Sensing Solutions Co., Ltd. All rights reserved.
 * Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 *
 *
 * @note
 *   === How to use this application ===
 *     1. Install this application using Adam Operation UI.
 *     2. Start this application using Adam Operation UI on web browser.
 *     3. Input the following URL on web browser.
 *          http://@IP_ADDRESS@/cgi-bin/adam.cgi?methodName=sendDataToAdamApplication&installId=@INSTALL_ID@&s_appDataType=0&s_appData=
 *           @IP_ADDRESS@ : IP address of device which is executed this application.
 *           @INSTALL_ID@ : Install Id of this application.
 *     4. If sucess, displayed a DNN result on web browser.
 */



/** Header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "pthread.h"

/** Header file for AdamApp Header */
#include "AdamApi.h"  

/** Header files for Debug Log */
#define ADAM_APP_DEBUG_ENABLE 1
#include "AdamDebug.h"
#include "AdamAssert.h"

/** Header file for AppPrefs */
#include "appprefs.h"

// struct of parameter to line top 5 and save them
typedef struct ST_RESULT_LIST_t {
	unsigned int		m_label;
	float			m_result;
} ST_RESULT_LIST;

/**
 *   Image resolution before resizing
 *   リサイズ前画像解像度
*/
static unsigned int in_height;
static unsigned int in_width;

/**
 *   Image resolution after resizing
 *   リサイズ後画像解像度
*/
#define OUTSIZE_HEIGHT		224
#define OUTSIZE_WIDTH		224

#define DEPTH_YCRESIZE		1.5
#define DEPTH_RGBRESIZE		3

#define NETNAME				"mobilenet_cavalry.bin"
#define LAYERNAMEIN			"data"
#define LAYERNAMEOUT_PROB	"prob"

/** Static variables */
static T_ADAM_EVENTLOOP_ID   s_systemEventloopId = ADAM_INVALID_EVENTLOOP_ID; /* System Eventloop */
static T_ADAM_DEV_RAWVIDEO_ID s_ycvideoDevId = ADAM_INVALID_DEV_ID;

static unsigned int s_count = 0;
static void* pDataOutAdr_prob = NULL;
static uint32_t output_size = 0;
static T_ADAM_NET_ID netid = -1;

static ST_ADAM_BLOB ycInBlob;
static ST_ADAM_BLOB rgbBlob;
static ST_ADAM_BLOB netInBlob;
static ST_ADAM_BLOB netOutBlob;

/** Data to send to HTML by web socket */
#define SEND_DATA_MAX	1024
static ST_RESULT_LIST result_list[5];
static char send_data[SEND_DATA_MAX + 1];

/** label-objectname matrix*/
const char* labelname[] = {
	"Chihuahua",
	"Japanese_spaniel",
	"Maltese_dog",
	"Pekinese",
	"Shih-Tzu",
	"Blenheim_spaniel",
	"papillon",
	"Toy_terrier",
	"Rhodesian_ridgeback",
	"Afghan_hound",
	"Basset",
	"Beagle",
	"Bloodhound",
	"Bluetick",
	"Black-and-tan_coonhound",
	"Walker_hound",
	"English_foxhound",
	"Redbone",
	"Borzoi",
	"Irish_wolfhound",
	"Italian_greyhound",
	"Whippet",
	"Ibizan_hound",
	"Norwegian_elkhound",
	"Otterhound",
	"Saluki",
	"Scottish_deerhound",
	"Weimaraner",
	"Staffordshire_bullterrier",
	"American_Staffordshire_terrier",
	"Bedlington_terrier",
	"Border_terrier",
	"Kerry_blue_terrier",
	"Irish_terrier",
	"Norfolk_terrier",
	"Norwich_terrier",
	"Yorkshire_terrier",
	"Wire-haired_fox_terrier",
	"Lakeland_terrier",
	"Sealyham_terrier",
	"Airedale",
	"Cairn",
	"Australian_terrier",
	"Dandie_Dinmont",
	"Boston_bull",
	"Miniature_schnauzer",
	"Giant_schnauzer",
	"Standard_schnauzer",
	"Scotch_terrier",
	"Tibetan_terrier",
	"Silky_terrier",
	"Soft-coated_wheaten_terrier",
	"West_Highland_white_terrier",
	"Lhasa",
	"Flat-coated_retriever",
	"Curly-coated_retriever",
	"Golden_retriever",
	"Labrador_retriever",
	"Chesapeake_Bay_retriever",
	"German_short-haired_pointer",
	"Vizsla",
	"English_setter",
	"Irish_setter",
	"Gordon_setter",
	"Brittany_spaniel",
	"Clumber",
	"English_springer",
	"Welsh_springer_spaniel",
	"Cocker_spaniel",
	"Sussex_spaniel",
	"Irish_water_spaniel",
	"Kuvasz",
	"Schipperke",
	"Groenendael",
	"Malinois",
	"Briard",
	"Kelpie",
	"Komondor",
	"Old_English_sheepdog",
	"Shetland_sheepdog",
	"Collie",
	"Border_collie",
	"Bouvier_des_Flandres",
	"Rottweiler",
	"German_shepherd",
	"Doberman",
	"Miniature_pinscher",
	"Greater_Swiss_Mountain_dog",
	"Bernese_mountain_dog",
	"Appenzeller",
	"EntleBucher",
	"Boxer",
	"Bull_mastiff",
	"Tibetan_mastiff",
	"French_bulldog",
	"Great_Dane",
	"Saint_Bernard",
	"Eskimo_dog",
	"Malamute",
	"Siberian_husky",
	"Affenpinscher",
	"Basenji",
	"Pug",
	"Leonberg",
	"Newfoundland",
	"Great_Pyrenees",
	"Samoyed",
	"Pomeranian",
	"Chow",
	"Keeshond",
	"Brabancon_griffon",
	"Pembroke",
	"Cardigan",
	"Toy_poodle",
	"Miniature_poodle",
	"Standard_poodle",
	"Mexican_hairless",
	"Dingo",
	"Dhole",
	"African_hunting_dog"
};

/** Function declarations */
extern int main( int argc, char* argv[] );
static E_ADAM_ERR create_DevYcVideo();
static void	stop_handler( E_ADAM_STOP_FACTOR factor );
static void	server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData );
static void	ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg );
static int	runnet(void);
void response_by_html( T_ADAM_REQUEST_ID requestId );

void line_top5(void);

extern int main3(int argc, const char **argv);
extern void sendResult(char* send_data, unsigned int send_width, unsigned int send_height);
/*******************************************************************************/

/**
 * @brief thread for connection
 *        ADAMとの通信用スレッド
 * @param p   [in] void*   some arguments
 */
void *func_thread(void *p){
	main3(0, NULL);
}


/**
 *   @brief main function
 *
 *   @param argc   [in] int   Count of arguments
 *   @param argv[] [in] char* Arguments
 *
 *   @return int 0      Normal response
 *   @return int <0     Abnormal response
 */
int main( int argc, char* argv[] )
{
	E_ADAM_ERR			err;			/** ADAM error code */
	int				ret = 0;		/** Return value of this function */
	ST_ADAM_SYSTEM_HANDLERS		handlers;		/** Handlers required by ADAM system */
	E_ADAM_START_FACTOR		startFactor;		/** Start factor (In this Adam version, not defined) */
	pthread_t			pthread;		/** Thread for web-socket */

	/**
	 *  Start to use ADAM library
	 *  ADAMライブラリの使用開始
	 *   Create the system event loop and set systemEventloopId
	 *   同時にイベントループも生成され、systemEventloopIdが返される
	 *   Arg 1 is the coding model about this application
	 *   第一引数ではアプリのコーディングモデルを指定する。
	 *   - ADAM_APP_TYPE_SKELETON   : Create only the main thread and use worker threads
	 *                                メインスレッドとWorkerスレッドのみで全ての処理を行うモデル。
	 *   - ADAM_APP_TYPE_FREE_STYLE : User can freely make threads for this application
	 *                                自由にスレッドを起こして処理を行うモデル。
	 *    This sample program is using the model of SKELETON.
	 *    （このアプリはSKELETONモデルとして動作します）
	 */
	handlers.m_stopHandler                 = stop_handler;
	handlers.m_serverRequestReceiveHandler = server_request_receive_handler;
	handlers.m_notifyAppPrefUpdateHandler  = 0;
	err = ADAM_Open( ADAM_APP_TYPE_SKELETON, &handlers, &s_systemEventloopId, &startFactor );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Open: ERROR=%d\n", err);
		ret = -1;
		goto errend;
	}

	pthread_create(&pthread, NULL, &func_thread, NULL);	//To use connection from HTM in ADAM

	/**
	 *    設定値情報初期化 (設定値情報から必要な値を取得)
	 *    Initialize the AppPrefs. (Get the needed parameter from AppPrefs.)
	 */
	appprefs_init();

    /**
     *   Open neural network definition file
     *   Neural Networkの定義ファイルオープン
     */
	err = ADAM_AI_OpenNet(NETNAME, &netid);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_OpenNet err! err:%d\n",err);
		ret = -2;
		goto adam_close;
	}

	in_height = appprefs_get_resolution_height();
	in_width = appprefs_get_resolution_width();

    /**
     *   Create Blob data area before resizing
     *   リサイズ前Blobデータ領域を作成
     */
	err = ADAM_CV_CreateBlob(ADAM_YC_CHANNELS, in_height, in_width, 1, &ycInBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_CreateBlob err! err:%d\n",err);
		ret = -3;
		goto net_close;
	}

    /**
     *   Create Blob data area after converting to BGR
     *   BGR変換後Blobデータ領域を作成
     */
	err = ADAM_CV_CreateBlob(DEPTH_RGBRESIZE, in_height, in_width, 1, &rgbBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_CreateBlob err! err:%d\n",err);
		ret = -4;
		goto yc_in_blob_close;
	}

    /**
     *   Get input blob data area of neural network
     *   Neural Networkの入力Blobデータ領域取得
     */
	err = ADAM_AI_BlobByName(netid, LAYERNAMEIN, &netInBlob);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_BlobByName(data) err! err:%d\n",err);
		ret = -5;
		goto yc_out_blob_close;
	}

    /**
     *   Get output blob data area of neural network
     *   Neural Networkの出力Blobデータ領域取得
     */
	err = ADAM_AI_BlobByName(netid, LAYERNAMEOUT_PROB, &netOutBlob);
	if ( ADAM_ERR_OK != err ) {
        ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_BlobByName(out_prob) err! err:%d\n",err);
		ret = -6;
		goto yc_out_blob_close;
	}

    /**
     *   Malloc output data buffer
     *   出力データエリア確保
     */
	output_size = netOutBlob.m_channels * netOutBlob.m_height * netOutBlob.m_width * 4;
	pDataOutAdr_prob = malloc(output_size);
	if(pDataOutAdr_prob == NULL){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "malloc err!\n");
		ret = -7;
		goto yc_out_blob_close;
	}

	/**
	 *   YcVideo取得用資源の生成とイベントループへの登録
	 *   Generates a YcVideo resource and registers it in System Eventloop
	 */
	err = create_DevYcVideo( s_systemEventloopId );
	if( ADAM_ERR_OK != err ){
		ret = -8;
		goto data_out_adr_close;
	}

	/**
	 *  Start main event loop
	 *  イベントループの開始
	 *   This function is loops infinitely until ADAM_Eventloop_Exit() is called.
	 *   ADAM_Eventloop_Exit()が呼ばれるまで、この関数から抜けてこず
	 *   Call the registered event handlers when events occur.
	 *   各種イベント発生毎に、登録したイベントハンドラが呼ばれる。
	 */
	err = ADAM_Eventloop_Dispatch( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Dispatch: ERROR=%d\n", err);
		ret = -9;
	}

	/**
	 *  Call stop_handler() when the event loop receives the stop application event
	 *  システム(コア)から終了通知を受けると、stop_handlerが呼ばれる。
	 *
	 *  stop_handler() calls ADAM_Eventloop_Exit(), so ADAM_Eventloop_Dispatch()
	 *  will quit the loop and return to this main() function.
	 *  stop_handlerの実装でADAM_Eventloop_Exit()を呼び出しているので、
	 *  ADAM_Eventloop_Dispatch()から抜けて、このmain()関数に処理が戻る。
	 */

data_out_adr_close:
    /**
     *   Release output data area
     *   出力データエリア解放
     */
	if(pDataOutAdr_prob != NULL){
		free(pDataOutAdr_prob);
	}
yc_out_blob_close:
    /**
     *   Delete the output Blob data area
     *   出力Blobデータ領域を削除
     */
	err = ADAM_CV_DeleteBlob(&rgbBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_DeleteBlob err!\n");
	}
yc_in_blob_close:
    /**
     *   Delete input Blob data area
     *   入力Blobデータ領域を削除
     */
	err = ADAM_CV_DeleteBlob(&ycInBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_DeleteBlob err!\n");
	}
net_close:
	/** Neural Networkクローズ*/
	err = ADAM_AI_CloseNet(netid);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_AI_CloseNet err!\n");
		ret = -10;
	}
adam_close:
	/** ADAMライブラリの使用終了*/
	err = ADAM_Close();
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Close: ERROR=%d\n", err);
		ret = -11;
	}
errend:
	return ret;
}

/**
 *   @brief YcVideo取得用資源の生成とイベントループへの登録
 *          Generates a YcVideo resource and registers it in Eventloop
 *
 *   @param eventloopId   [in] int   Eventloop Id
 *
 *   @return ADAM_ERR_OK         Normal response
 *   @return except ADAM_ERR_OK  Abnormal response
 */
E_ADAM_ERR create_DevYcVideo( T_ADAM_EVENTLOOP_ID eventloopId )
{
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "create_DevYcVideo start\n");

	ST_ADAM_DEV_YCVIDEO_PROPERTY property;
	appprefs_get_YcVideoProperty(&property);

	/** Generate a Yc video Resource. */
	E_ADAM_ERR err = ADAM_DevYcVideo_Create( &property, ycvideo_handler, (void*)(1001), &s_ycvideoDevId );
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "create_DevYcVideo(1)\n");

	if ( ADAM_ERR_OK != err ){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_DevYcVideo_Create: ERROR=%d\n", err);
		return err;
	}

	/** Regeister a Yc video resource in Eventloop. */
	err = ADAM_Eventloop_Add( eventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Add: ERROR=%d\n", err);
		return err;
	}

	return ADAM_ERR_OK;
}


/**
 *  @brief Handler for the application STOP request from adamCore process
 *         終了イベントハンドラ
 *  @param factor   [in] E_ADAM_STOP_FACTOR   Stop factor
 */
void stop_handler( E_ADAM_STOP_FACTOR factor )
{
	/**
	 *   Remove the Yc video resource from System Eventloop.
	 *   (In this removal, the Yc video resource is destroyed.)
	 *   システムイベントループから、YcVideo取得用資源を削除
	 *    (この削除により、YcVideo取得用資源も破棄されます)
	 */
	E_ADAM_ERR err = ADAM_Eventloop_Remove( s_systemEventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Remove: ERROR=%d\n", err);
	}

	/**
	 *   Request the main eventloop to stop
	 *   main()側のイベントループの終了を指示
	 */
	err = ADAM_Eventloop_Exit( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_Eventloop_Exit: ERROR=%d\n", err);
	}
}


/**
 * @brief Handler for the sending application data request from the host ( via adamCore )
 *        アプリデータ受信ハンドラ
 *
 * @param requestId [in] T_ADAM_REQUEST_ID   Request ID
 * @param pData     [in] ST_ADAM_NET_DATA    Received Data
 */
void server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData )
{
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "requestId=%x start\n", (int)requestId);
	response_by_html(requestId);
	return;
}

/**
 *   @brief Handler to notify to receive Yc Video data
 *          Yc画像受信イベントハンドラの記述
 *
 *   @param devId [in] T_ADAM_DEV_YCVIDEO_ID     YCVIDEO device ID
 *   @param pData [in] ST_ADAM_DEV_YCVIDEO_DATA* YCVIDEO data
 */

void ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg )
{
	int ret;
	E_ADAM_ERR err;

	ADAM_ASSERT( s_ycvideoDevId == devId );

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "ycvideo_handler start\n");

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "%05d: ycvideo devid = %ld, ycvideo data size = %d\n",
                     ++s_count, (long)devId, pData->m_size);

    /**
     *   Set data to Blob before resizing
     *   リサイズ前Blobへデータを設定
     */
	err = ADAM_CV_SetCpuData(&ycInBlob, pData->m_pData);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_SetCpuData err! err:%d\n",err);
		return;
	}

	ST_ADAM_AREA_INFO resizeIn;
	memset(&resizeIn, 0x00, sizeof(ST_ADAM_AREA_INFO));
	memcpy(&resizeIn.m_blob, &ycInBlob, sizeof(ST_ADAM_BLOB));

    /**
     *   Convert YC image to RGB image
     *   YC画像をBGR画像に変換
     */
	err = ADAM_CV_Yc2Rgb(&resizeIn, &rgbBlob, ADAM_COLOR_ORDER_BGR);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_Yc2Rgb err! err:%d\n",err);
		return;
	}

    ST_ADAM_AREA_INFO rgbInfo;
	memset(&rgbInfo, 0x00, sizeof(ST_ADAM_AREA_INFO));
	memcpy(&rgbInfo.m_blob, &rgbBlob, sizeof(ST_ADAM_BLOB)); 

    /**
     *   Resize RGB image
     *   RGB画像リサイズ
     */
	err = ADAM_CV_RgbResize(&rgbInfo, &netInBlob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_RgbResize err! err:%d\n",err);
		return;
	}

    /**
     *   Run inference of neural network
     *   Networkの推論実行
     */
	ret = runnet();
	if(ret != 0){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "runnet err! ret:%d\n",ret);
		return;
	}

    /**
     *   Send result of inference to HTML by ws
     *   推論結果の送信
     */
	line_top5();
	sendResult(send_data, in_width, in_height);

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "ycvideo_handler end\n");
}

/**
 * @brief Send the response data whose format is HTML
 *        HTML形式のレスポンスを返す
 * @param requestId [in] T_ADAM_REQUEST_ID   Request ID
 */
void response_by_html(T_ADAM_REQUEST_ID requestId)
{
	// Data for sending set by ADAM_ServerResponse_Send()
	// ADAM_ServerResponse_Sendに設定するデータ
	ST_ADAM_NET_DATA	resData;
	char*			htmlData = (char*)malloc(4096);		// HTML body data to send
	int			bodySize = 0;				// HTML body data size
	char*			outputData = (char*)malloc(4096);	// Response data(HTTP header + body)
	int			size = 0;				// Response data size
	E_ADAM_ERR		ret;

	const char *appPath = ADAM_GetAppDataDirPath();
	char fname[512];
	snprintf(fname, sizeof(fname), "%s/sample.htm", appPath);
	FILE *fp = fopen(fname, "r");
	if(fp){
		char buf[512];
		while(fgets(buf, 512, fp)){
			bodySize += sprintf(htmlData + bodySize, "%s\n", buf);
		}
		fclose(fp);
	}

	// Make sample HTML header (to calculate body size, this data is made after making HTML body)
	// サンプルのHTMLヘッダを生成(length計算のためにHTMLより後に生成が必要)
	size += sprintf(outputData + size, "HTTP/1.1 200 OK\n");
	size += sprintf(outputData + size, "Content-Type: text/html\n");
	size += sprintf(outputData + size, "Content-Length: %d\n", bodySize + 1);
	size += sprintf(outputData + size, "\n");

	// Add body behind the header
	// ヘッダの後ろにボディを連結
	memcpy(outputData + size, htmlData, bodySize);
	size += bodySize;

	resData.m_type  = 0;				// Ignore m_type when HTML mode
	resData.m_pData = outputData;			// Set the pointer of response data
	resData.m_size  = size;				// Response data size

	// Send response by ADAM_USER_DEFINED_FORMAT
	// ADAM_USER_DEFINED_FORMATとしてレスポンスを返す
	ret = ADAM_ServerResponse_Send(requestId, ADAM_USER_DEFINED_FORMAT, &resData);
	if(ADAM_ERR_OK != ret){
		// error handling
	}

	free(outputData);
	free(htmlData);
}

/**
 *  @brief Run inference of neural network
 *         Networkの推論実行
 */
int	runnet(void)
{
	E_ADAM_ERR err;

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runnet start\n");
    
    /**
     *   Run inference of neural network
     *   Networkの推論実行
     */
	err = ADAM_AI_RunNet(netid);
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "runnet err! err:%d\n",err);
		return -1;
	}

    /**
     *   Get output data from Blob after Network inference
     *   Networkの推論後Blobより出力データ取得
     */
	err = ADAM_CV_GetCpuData(&netOutBlob, pDataOutAdr_prob);
	if(err != ADAM_ERR_OK){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR, "ADAM_CV_GetCpuData err! err:%d\n",err);
		return -1;
	}

	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "runnet end\n");
    return 0;

}


/**
 *  @brief Line inferred data to send only top 5
 *         推論後のデータをスコア上位５つで並べる
 */
void line_top5(void){
	float score;
	uint8_t *pAdr = (uint8_t *)pDataOutAdr_prob;
	memset(send_data, '\0', (SEND_DATA_MAX + 1));
	for(int i = 0; i < 5; i++){
		result_list[i].m_result = 0;
		result_list[i].m_label = 0;
	}

	for(uint32_t cnt = 0;cnt < output_size/(uint32_t)sizeof(float);cnt++){
		memcpy(&score, pAdr, sizeof(float));

		if(score > result_list[0].m_result){
			result_list[4].m_result = result_list[3].m_result;
			result_list[4].m_label = result_list[3].m_label;
			result_list[3].m_result = result_list[2].m_result;
			result_list[3].m_label = result_list[2].m_label;
			result_list[2].m_result = result_list[1].m_result;
			result_list[2].m_label = result_list[1].m_label;
			result_list[1].m_result = result_list[0].m_result;
			result_list[1].m_label = result_list[0].m_label;
			result_list[0].m_result = score;
			result_list[0].m_label = cnt;
		}
		else if(score > result_list[1].m_result){
			result_list[4].m_result = result_list[3].m_result;
			result_list[4].m_label = result_list[3].m_label;
			result_list[3].m_result = result_list[2].m_result;
			result_list[3].m_label = result_list[2].m_label;
			result_list[2].m_result = result_list[1].m_result;
			result_list[2].m_label = result_list[1].m_label;
			result_list[1].m_result = score;
			result_list[1].m_label = cnt;
		}
		else if(score > result_list[2].m_result){
			result_list[4].m_result = result_list[3].m_result;
			result_list[4].m_label = result_list[3].m_label;
			result_list[3].m_result = result_list[2].m_result;
			result_list[3].m_label = result_list[2].m_label;
			result_list[2].m_result = score;
			result_list[2].m_label = cnt;
		}
		else if(score > result_list[3].m_result){
			result_list[4].m_result = result_list[3].m_result;
			result_list[4].m_label = result_list[3].m_label;
			result_list[3].m_result = score;
			result_list[3].m_label = cnt;
		}
		else if(score > result_list[4].m_result){
			result_list[4].m_result = score;
			result_list[4].m_label = cnt;
		}

		pAdr+=sizeof(float);
	}

	// Set data lined top 5 to send
	snprintf(send_data, SEND_DATA_MAX, "%s :%f\n%s :%f\n%s :%f\n%s :%f\n%s :%f", 
			labelname[result_list[0].m_label], result_list[0].m_result,
			labelname[result_list[1].m_label], result_list[1].m_result,
			labelname[result_list[2].m_label], result_list[2].m_result,
			labelname[result_list[3].m_label], result_list[3].m_result,
			labelname[result_list[4].m_label], result_list[4].m_result);

}
/*! @} */
