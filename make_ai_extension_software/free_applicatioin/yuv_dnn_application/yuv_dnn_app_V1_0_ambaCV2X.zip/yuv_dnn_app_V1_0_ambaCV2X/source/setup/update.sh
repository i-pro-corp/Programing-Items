echo 'Updater start'

# アプリ更新時に必要な処理を記述する(空でもよい)

echo 'Updater done'

exit 0
