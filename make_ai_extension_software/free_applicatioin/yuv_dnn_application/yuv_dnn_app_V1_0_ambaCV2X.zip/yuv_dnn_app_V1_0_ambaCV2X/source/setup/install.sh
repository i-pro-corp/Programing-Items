echo 'Installer start'

# アプリインストール時に必要な処理を記述する(空でもよい)

echo 'Installer done'

exit 0
