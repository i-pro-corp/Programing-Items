/*!
 * @addtogroup  Adam Sample Application
 * @{
 * @file        main.c
 * @brief       Adam OpenCV Edge Detection Sample Application (SKELETON Model)
 *
 * @author      A.Nakano
 * @version     1.00 (2020-03-30)
 *
 * @par Copyright
 *  Copyright (C) 2019 Panasonic i-PRO Sensing Solutions Co., Ltd. All rights reserved.
 *  Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 *
 * @note
 *   === How to use this application ===
 *     1. Install this application using Adam Operation UI.
 *     2. Start this application using Adam Operation UI on web browser.
 *     3. Input the following URL on web browser.
 *          http://@IP_ADDRESS@/cgi-bin/adam.cgi?methodName=sendDataToAdamApplication&installId=@INSTALL_ID@&s_appDataType=0&s_appData=
 *           @IP_ADDRESS@ : IP address of device which is executed this application.
 *           @INSTALL_ID@ : Install Id of this application.
 *     4. If sucess, displayed a JPEG image getting camera on web browser.
 */



/** Header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** Header file for AdamApp Header */
#include "AdamApi.h"  

/** Header files for Debug Log */
#define ADAM_APP_DEBUG_ENABLE 1
#include "AdamDebug.h"
#include "AdamAssert.h"

/** Header file for AppPrefs */
#include "appprefs.h"

/** Header file for OpenCV library */
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

/** Temporary file to use as jpeg */
#define TEMP_JPEGFILE	"tmp.jpg"
static const char * tmpPath = NULL;

using namespace cv;

/** Static variables */
static T_ADAM_EVENTLOOP_ID   s_systemEventloopId = ADAM_INVALID_EVENTLOOP_ID; /* System Eventloop */
static T_ADAM_DEV_YCVIDEO_ID s_ycvideoDevId = ADAM_INVALID_DEV_ID;
static unsigned int s_ycSize = 0;
static unsigned char* s_pYcData = NULL;
static unsigned int s_count = 0;

/** Variables to use Canny Edge Detection */
static Mat src;
static Mat detected_edges;
static int in_width = 0;
static int in_height = 0;
static int in_threshold = 0;
static const int ratio = 3;
static const int kernel_size = 3;

/** Variables to load jpeg-data */
static char* gpJpegTop = NULL;
static unsigned long gjpegSize = 0;

/** Function declarations */
extern int main( int argc, char* argv[] );

static E_ADAM_ERR create_DevYcVideo(T_ADAM_EVENTLOOP_ID eventloopId);
static void	stop_handler( E_ADAM_STOP_FACTOR factor );
static void	server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData );
#if (ADAM_ADAMAPI_API_VERSION >= 2)
static void	ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg );
#else
static void	ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData );
#endif

// Method to use Canny Edge Detection
void	proc_canny_edge_detectin(void);
void	canny_threshold(int, void*);

/*******************************************************************************/


/**
 *   @brief main function
 *
 *   @param argc   [in] int   Count of arguments
 *   @param argv[] [in] char* Arguments
 *
 *   @return int 0      Normal response
 *   @return int <0     Abnormal response
 */
int
main( int argc, char* argv[] )
{
	E_ADAM_ERR				err;			/** ADAM error code */
	int						ret = 0;		/** Return value of this function */
	ST_ADAM_SYSTEM_HANDLERS	handlers;		/** Handlers required by ADAM system */
	E_ADAM_START_FACTOR		startFactor;	/** Start factor (In this Adam version, not defined) */

	/**
	 *  Start to use ADAM library
	 *  ADAMライブラリの使用開始
	 *   Create the system event loop and set systemEventloopId
	 *   同時にイベントループも生成され、systemEventloopIdが返される
	 *   Arg 1 is the coding model about this application
	 *   第一引数ではアプリのコーディングモデルを指定する。
	 *   - ADAM_APP_TYPE_SKELETON   : Create only the main thread and use worker threads
	 *                                メインスレッドとWorkerスレッドのみで全ての処理を行うモデル。
	 *   - ADAM_APP_TYPE_FREE_STYLE : User can freely make threads for this application
	 *                                自由にスレッドを起こして処理を行うモデル。
	 *    This sample program is using the model of SKELETON.
	 *    （このアプリはSKELETONモデルとして動作します）
	 */
	handlers.m_stopHandler                 = stop_handler;
	handlers.m_serverRequestReceiveHandler = server_request_receive_handler;
	handlers.m_notifyAppPrefUpdateHandler  = 0;
	err = ADAM_Open( ADAM_APP_TYPE_SKELETON, &handlers, &s_systemEventloopId, &startFactor );
	if ( ADAM_ERR_OK != err ) { 
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Open: ERROR=%d\n", err);
		ret = -1;
		goto errend;
	}

	/**
	 *    設定値情報初期化 (設定値情報から必要な値を取得)
	 *    Initialize the AppPrefs. (Get the needed parameter from AppPrefs.)
	 */
	appprefs_init();
	in_threshold = appprefs_get_threshold();
	in_width = appprefs_get_resolution_width();
	in_height = appprefs_get_resolution_height();
	src = Mat::zeros(in_height, in_width, CV_8UC1);	// Initialize Mat-data by used parameters
	tmpPath = ADAM_GetAppTmpDirPath();

	/**
	 *   YcVideo取得用資源の生成とイベントループへの登録
	 *   Generates a YcVideo resource and registers it in System Eventloop
	 */
	err = create_DevYcVideo( s_systemEventloopId );
	if( ADAM_ERR_OK != err ){
		ret = -2;
		goto errend;
	}

	/**
	 *  Start main event loop
	 *  イベントループの開始
	 *   This function is loops infinitely until ADAM_Eventloop_Exit() is called.
	 *   ADAM_Eventloop_Exit()が呼ばれるまで、この関数から抜けてこず
	 *   Call the registered event handlers when events occur.
	 *   各種イベント発生毎に、登録したイベントハンドラが呼ばれる。
	 */
	err = ADAM_Eventloop_Dispatch( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Eventloop_Dispatch: ERROR=%d\n", err);
		ret = -3;
	}

	/**
	 *  Call stop_handler() when the event loop receives the stop application event
	 *  システム(コア)から終了通知を受けると、stop_handlerが呼ばれる。
	 *
	 *  stop_handler() calls ADAM_Eventloop_Exit(), so ADAM_Eventloop_Dispatch()
	 *  will quit the loop and return to this main() function.
	 *  stop_handlerの実装でADAM_Eventloop_Exit()を呼び出しているので、
	 *  ADAM_Eventloop_Dispatch()から抜けて、このmain()関数に処理が戻る。
	 */

	/** Release buffer for Yc area. */
	free( s_pYcData );

	/**
	 *   Close ADAM library
	 *   ADAMライブラリの使用終了
	 */
	err = ADAM_Close();
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Close: ERROR=%d\n", err);
		ret = -4;
	}

errend:
	return ret;
}


/**
 *   @brief YcVideo取得用資源の生成とイベントループへの登録
 *          Generates a YcVideo resource and registers it in Eventloop
 *
 *   @param eventloopId   [in] int   Eventloop Id
 *
 *   @return ADAM_ERR_OK         Normal response
 *   @return except ADAM_ERR_OK  Abnormal response
 */
E_ADAM_ERR
create_DevYcVideo( T_ADAM_EVENTLOOP_ID eventloopId )
{
	ST_ADAM_DEV_YCVIDEO_PROPERTY property;
	appprefs_get_YcVideoProperty(&property);

	/** Generate a Yc video Resource. */
#if (ADAM_ADAMAPI_API_VERSION >= 2)
	E_ADAM_ERR err = ADAM_DevYcVideo_Create( &property, ycvideo_handler, (void*)(1001), &s_ycvideoDevId );
#else
	E_ADAM_ERR err = ADAM_DevYcVideo_Create( &property, ycvideo_handler, &s_ycvideoDevId );
#endif
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_DevYcVideo_Create: ERROR=%d\n", err);
		return err;
	}

	/** Regeister a Yc video resource in Eventloop. */
	err = ADAM_Eventloop_Add( eventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Eventloop_Add: ERROR=%d\n", err);
		return err;
	}

	return ADAM_ERR_OK;
}


/**
 *  @brief Handler for the application STOP request from adamCore process
 *         終了イベントハンドラ
 *  @param factor   [in] E_ADAM_STOP_FACTOR   Stop factor
 */
void
stop_handler( E_ADAM_STOP_FACTOR factor )
{
	/**
	 *   Remove the Yc video resource from System Eventloop.
	 *   (In this removal, the Yc video resource is destroyed.)
	 *   システムイベントループから、YcVideo取得用資源を削除
	 *    (この削除により、YcVideo取得用資源も破棄されます)
	 */
	E_ADAM_ERR err = ADAM_Eventloop_Remove( s_systemEventloopId, s_ycvideoDevId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Eventloop_Remove: ERROR=%d\n", err);
	}

	/**
	 *   Request the main eventloop to stop
	 *   main()側のイベントループの終了を指示
	 */
	err = ADAM_Eventloop_Exit( s_systemEventloopId );
	if ( ADAM_ERR_OK != err ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"ADAM_Eventloop_Exit: ERROR=%d\n", err);
	}
}


/**
 * @brief Handler for the sending application data request from the host ( via adamCore )
 *        アプリデータ受信ハンドラ
 *
 * @param requestId [in] T_ADAM_REQUEST_ID   Request ID
 * @param pData     [in] ST_ADAM_NET_DATA    Received Data
 */
void
server_request_receive_handler( T_ADAM_REQUEST_ID requestId, ST_ADAM_NET_DATA* pData )
{
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "requestId=%x start s_ycSize=%d\n", (int)requestId, s_ycSize);

	/** Header information of response data. */
	const char pHeader[] = "Status: 200\r\n"
                           "X-Content-Type-Options: nosniff\r\n"
                           "Content-Type: image/jpeg\r\n" 
                           "Cache-Control: no-cache\r\n"
                           "Connection: Close\r\n";
	int headerSize = strlen(pHeader);

	/** Malloc response data buffer. */
	if(gpJpegTop == NULL){
		gpJpegTop = (char*)malloc( s_ycSize );
	}
	/** Malloc response data buffer. */
	char fname[128];
	sprintf(fname, "%s/%s", tmpPath, TEMP_JPEGFILE);
	FILE *jpeg_fp = fopen(fname, "rb");

	/** Load jpeg-data to show */
	if (jpeg_fp== NULL) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"file open err file: %s\n", fname);
		return;
	}else{
		gjpegSize = fread(gpJpegTop, 1 ,s_ycSize ,jpeg_fp);
	}
	fclose(jpeg_fp);
	char cmd[128];
	sprintf(cmd, "rm %s/%s", tmpPath, TEMP_JPEGFILE);
	system(cmd);
	if(gjpegSize == 0){
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"file size err, size:0\n");
		return;
	}

	/** Send response data. */
	ST_ADAM_HTTP_DATA resHeader;
	resHeader.m_dataType = ADAM_HTTP_DATA_TYPE_BUF;
	resHeader.m_data.m_buf.m_pData = (void*)pHeader;
	resHeader.m_data.m_buf.m_size = headerSize;

	ST_ADAM_HTTP_DATA resBody;
	resBody.m_dataType = ADAM_HTTP_DATA_TYPE_BUF;
	resBody.m_data.m_buf.m_pData = gpJpegTop;
	resBody.m_data.m_buf.m_size = gjpegSize;

	E_ADAM_ERR ret = ADAM_ServerResponse_SendAsIs( requestId, &resHeader, &resBody );
	if ( ADAM_ERR_OK != ret ) {
		ADAM_DEBUG_PRINT(ADAM_LV_ERR,"requestId=%x err %d\n", (int)requestId, ret);
	}

	return;
}


/**
 *   @brief Handler to notify to receive Yc Video data
 *          Yc画像受信イベントハンドラの記述
 *
 *   @param devId [in] T_ADAM_DEV_YCVIDEO_ID     YCVIDEO device ID
 *   @param pData [in] ST_ADAM_DEV_YCVIDEO_DATA* YCVIDEO data
 */

#if (ADAM_ADAMAPI_API_VERSION >= 2)
void
ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData, void* pArg )
#else
void
ycvideo_handler( T_ADAM_DEV_YCVIDEO_ID devId, ST_ADAM_DEV_YCVIDEO_DATA* pData )
#endif
{
	ADAM_ASSERT( s_ycvideoDevId == devId );
	ADAM_DEBUG_PRINT(ADAM_LV_DBG, "%05d: ycvideo devid = %ld, ycvideo data size = %d\n",
                     ++s_count, (long)devId, pData->m_size);

	/** Malloc buffer for Yc data (If size of yc data is changed, realloc buffer.) */
	if( s_ycSize != (unsigned int)(pData->m_size) ){
		s_ycSize = pData->m_size;
		free( s_pYcData );
		s_pYcData = (unsigned char*)malloc( s_ycSize );
	}

	memcpy( s_pYcData, pData->m_pData, pData->m_size );

	proc_canny_edge_detectin();	// Start Canny Edge Detection process

	return;
}


/**
 * @brief Process about Canny Edge Detection
 *        エッジ検出処理
 *
 */
void proc_canny_edge_detectin(void)
{
	ADAM_DEBUG_PRINT( ADAM_LV_DBG, "proc_canny_edge_detectin Start\n");

	int buf_pos = 0;
	char fname[128];

	for(int i = 0; i<in_height; i++){	// Copy Y-component of YC−image to Mat
		for(int j = 0; j<in_width; j++){
			src.at<unsigned char>(i, j) = s_pYcData[buf_pos];
			buf_pos++;
		}
	}

        if(src.empty())
        {
		ADAM_DEBUG_PRINT( ADAM_LV_ERR, "Empty image Mat\n");
        }
	else
	{
		canny_threshold(0, 0);	// Do Canny Edge Detection
		sprintf(fname, "%s/%s", tmpPath, TEMP_JPEGFILE);
		imwrite(fname, detected_edges);	// Save as jpeg file
	}

	ADAM_DEBUG_PRINT( ADAM_LV_DBG, "proc_canny_edge_detectin End\n");
}

/**
 * @brief Do edge detection
 *        エッジ検出の実行
 *
 * @param int	[in] need not to change
 * @param void*	[in] need not to change
 */
void canny_threshold(int, void*)
{
	ADAM_DEBUG_PRINT( ADAM_LV_DBG, "canny_threshold Start\n");

	blur(src, detected_edges, Size(3,3));
	Canny(detected_edges, detected_edges, in_threshold, in_threshold*ratio, kernel_size);

	ADAM_DEBUG_PRINT( ADAM_LV_DBG, "canny_threshold End\n");
}

/*! @} */
