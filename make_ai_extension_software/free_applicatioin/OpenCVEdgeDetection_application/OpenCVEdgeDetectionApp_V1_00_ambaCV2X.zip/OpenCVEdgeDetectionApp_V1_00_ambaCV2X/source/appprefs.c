/**
 * @addtogroup  Adam Sample Application
 * @{
 * @file        appprefs.c
 * @brief       Adam JPEG Sample Application (SKELETON Model)
 *
 * @author      K.Motosaka
 *
 * @par Copyright
 * Copyright (C) 2013,2014,2015,2017,2018 Panasonic Corporation. All rights reserved.
 * Copyright (C) 2022 i-PRO Co., Ltd. All rights reserved.
 */

#include "AdamDebug.h"
#include "AdamAssert.h"

#include "appprefs.h"

static int s_frameRate;
static unsigned int s_resolution;
static unsigned int s_threshold;

static struct {
	int m_width;
	int m_height;
} s_resolutions[] = {
	{1280,  720}, /** HD */
	{1920, 1080}, /** FHD */
};

E_ADAM_ERR appprefs_init(void)
{
	/** Lock to access from WebAPI (for exclusion). */
	ADAM_AppPref_Lock();

	/** Get Resolution */
	ADAM_AppPref_GetEnumeration("Resolution", &s_resolution);

	/** Get Frame rate */
	int64_t frameRate;
	ADAM_AppPref_GetInteger("FrameRate", &frameRate);
	s_frameRate = (int)frameRate;

	/** Get Min threshold */
	int64_t threshold;
	ADAM_AppPref_GetInteger("MinThreshold", &threshold);
	s_threshold = (unsigned int)threshold;

	/** Unlock to access from WebAPI. */
	ADAM_AppPref_Unlock();

	return ADAM_ERR_OK;
}


void appprefs_get_YcVideoProperty(ST_ADAM_DEV_YCVIDEO_PROPERTY* pProperty)
{
	/** set resolution  */
	int width = appprefs_get_resolution_width();
	int height = appprefs_get_resolution_height();
	pProperty->m_resolution = ADAM_SET_RESOLUTION(width, height);

	/** set frame rate */
	pProperty->m_frameRate = ADAM_SET_FRAME_RATE(s_frameRate, 1);

	return;
}


int appprefs_get_framerate(void)
{
	return s_frameRate;
}


int appprefs_get_resolution_width(void)
{
	return s_resolutions[s_resolution].m_width;
}


int appprefs_get_resolution_height(void)
{
	return s_resolutions[s_resolution].m_height;
}

unsigned int appprefs_get_threshold(void)
{
	return s_threshold;
}

/*! @} */
